#!/usr/bin/env node

const http = require('http');
const fs = require('fs');
const net = require('net');
const path = require('path');
const crypto = require('crypto');
const { Buffer } = require('buffer');
const axios = require('axios');
const { WebSocket, createWebSocketStream } = require('ws');

// ========================== 环境变量配置 ==========================
const UUID = process.env.UUID || '0058c4cc-82a2-4cd0-92ed-fe8286d261d2';
const DOMAIN = process.env.DOMAIN || ''; 
const AUTO_ACCESS = process.env.AUTO_ACCESS || false;      
const SUB_PATH = process.env.SUB_PATH || 'vercel';           
const NAME = process.env.NAME || 'Vercel';                       
const PORT = process.env.PORT || 3000;                    

// 日志控制 
const SHOW_LOG = !!(process.env.SHOW_LOG);
function log(...args) { if (SHOW_LOG) console.log(...args); }
function logErr(...args) { if (SHOW_LOG) console.error(...args); }
function logWarn(...args) { if (SHOW_LOG) console.warn(...args); }

// 辅助工具
const WSPATH = process.env.WSPATH || UUID.slice(0, 8); 
const uuid = UUID.replace(/-/g, "");
const DNS_SERVERS = ['8.8.4.4', '1.1.1.1'];
const BLOCKED_DOMAINS = [
  'speedtest.net', 'fast.com', 'speedtest.cn', 'speed.cloudflare.com', 'speedof.me',
  'testmy.net', 'bandwidth.place', 'speed.io', 'librespeed.org', 'speedcheck.org'
];

// block speedtest domains
function isBlockedDomain(host) {
  if (!host) return false;
  const hostLower = host.toLowerCase();
  return BLOCKED_DOMAINS.some(blocked => {
    return hostLower === blocked || hostLower.endsWith('.' + blocked);
  });
}

// 获取isp（重构为无副作用的纯异步函数）
async function getisp() {
  try {
    const res = await axios.get('https://api.ip.sb/geoip', { headers: { 'User-Agent': 'Mozilla/5.0', timeout: 3000 }});
    const data = res.data;
    return `${data.country_code}-${data.isp}`.replace(/ /g, '_');
  } catch (e) {
    try {
      const res2 = await axios.get('http://ip-api.com/json', { headers: { 'User-Agent': 'Mozilla/5.0', timeout: 3000 }});
      const data2 = res2.data;
      return `${data2.countryCode}-${data2.org}`.replace(/ /g, '_');
    } catch (e2) {
      return 'Unknown';
    }
  }
}

// 获取ip（重构为无副作用的纯异步函数）
async function getip() {
  try {
    const res = await axios.get('https://api-ipv4.ip.sb/ip', { timeout: 5000 });
    const ip = res.data.trim();
    return { currentDomain: ip, tlsStatus: 'none', currentPort: PORT };
  } catch (e) {
    logErr('Failed to get IP', e.message);
    return { currentDomain: 'change-your-domain.com', tlsStatus: 'tls', currentPort: 443 };
  }
}

// HTTP 路由
const httpServer = http.createServer(async (req, res) => {
  if (req.url === '/') {
    const filePath = path.join(__dirname, 'index.html');
    fs.readFile(filePath, 'utf8', (err, content) => {
      if (err) {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end('Hello world!');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
    });
    return;
  } else if (req.url === `/${SUB_PATH}`) {
    // 使用局部变量隔离状态，杜绝高并发下的状态竞争
    const currentISP = await getisp();
    
    // 动态提取当前请求的域名
    const dynamicHost = req.headers['x-forwarded-host'] || req.headers.host || '';
    let requestDomain = '';

    // 修复：兼容 IPv6 的 Host 解析，避免被 split(':') 错误截断
    if (dynamicHost.startsWith('[')) {
      const endIdx = dynamicHost.indexOf(']');
      requestDomain = endIdx !== -1 ? dynamicHost.substring(1, endIdx) : dynamicHost;
    } else {
      requestDomain = dynamicHost.split(':')[0];
    }

    let activeDomain, activeTls, activePort;

    if (!DOMAIN) {
      // 未设置环境变量时，若提取到合法域名（非本地且非IP），则使用该域名
      if (requestDomain && requestDomain !== 'localhost' && !net.isIP(requestDomain)) {
        activeDomain = requestDomain;
        activeTls = 'tls';
        activePort = PORT;
      } else {
        // 退化执行原有获取服务器 IP 的逻辑
        const ipFallback = await getip();
        activeDomain = ipFallback.currentDomain;
        activeTls = ipFallback.tlsStatus;
        activePort = ipFallback.currentPort;
      }
    } else {
      // 若已显式配置 DOMAIN 环境变量，强制使用配置值
      activeDomain = DOMAIN;
      activeTls = 'tls';
      activePort = 443;
    }

    const namePart = NAME ? `${NAME}-${currentISP}` : currentISP;
    const tlsParam = activeTls === 'tls' ? 'tls' : 'none';
    const ssTlsParam = activeTls === 'tls' ? 'tls;' : '';
    const vlsURL = `vless://${UUID}@${activeDomain}:${activePort}?encryption=none&security=${tlsParam}&sni=${activeDomain}&fp=chrome&type=ws&host=${activeDomain}&path=%2F${WSPATH}#${namePart}`;
    const troURL = `trojan://${UUID}@${activeDomain}:${activePort}?security=${tlsParam}&sni=${activeDomain}&fp=chrome&type=ws&host=${activeDomain}&path=%2F${WSPATH}#${namePart}`;
    const ssMethodPassword = Buffer.from(`none:${UUID}`).toString('base64');
    const ssURL = `ss://${ssMethodPassword}@${activeDomain}:${activePort}?plugin=v2ray-plugin;mode%3Dwebsocket;host%3D${activeDomain};path%3D%2F${WSPATH};${ssTlsParam}sni%3D${activeDomain};skip-cert-verify%3Dtrue;mux%3D0#${namePart}`;
    const subscription = vlsURL + '\n' + troURL + '\n' + ssURL;
    const base64Content = Buffer.from(subscription).toString('base64');

    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(base64Content + '\n');
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found\n');
  }
});

// Custom DNS
function resolveHost(host) {
  return new Promise((resolve, reject) => {
    if (/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(host) || net.isIPv6(host)) {
      resolve(host);
      return;
    }
    let attempts = 0;
    function tryNextDNS() {
      if (attempts >= DNS_SERVERS.length) {
        reject(new Error(`Failed to resolve ${host} with all DNS servers`));
        return;
      }
      const dnsServer = DNS_SERVERS[attempts];
      attempts++;
      const dnsQuery = `https://dns.google/resolve?name=${encodeURIComponent(host)}&type=A`;
      axios.get(dnsQuery, {
        timeout: 5000,
        headers: { 'Accept': 'application/dns-json' }
      })
        .then(response => {
          const data = response.data;
          if (data.Status === 0 && data.Answer && data.Answer.length > 0) {
            const ip = data.Answer.find(record => record.type === 1);
            if (ip) { resolve(ip.data); return; }
          }
          tryNextDNS();
        })
        .catch(error => { tryNextDNS(); });
    }
    tryNextDNS();
  });
}

// VLE-SS处理
function handleVlsConnection(ws, msg) {
  if (msg.length < 18) return false;
  const [VERSION] = msg;
  const id = msg.slice(1, 17);
  if (!id.every((v, i) => v == parseInt(uuid.substr(i * 2, 2), 16))) return false;

  let optLen = msg.readUInt8(17);
  let i = 18 + optLen;
  if (msg.length < i + 4) return false; 

  const cmd = msg.readUInt8(i);
  i += 1;
  const port = msg.readUInt16BE(i);
  i += 2;
  const ATYP = msg.readUInt8(i);
  i += 1;

  let host;
  if (ATYP === 1) { 
    if (msg.length < i + 4) return false;
    host = msg.slice(i, i += 4).join('.');
  } else if (ATYP === 2) { 
    if (msg.length < i + 1) return false;
    const domainLen = msg.readUInt8(i);
    i += 1;
    if (msg.length < i + domainLen) return false;
    host = msg.slice(i, i += domainLen).toString();
  } else if (ATYP === 3) { 
    if (msg.length < i + 16) return false;
    const ipv6Buf = msg.slice(i, i += 16);
    const ipv6Parts = [];
    for (let j = 0; j < 16; j += 2) {
      ipv6Parts.push(ipv6Buf.readUInt16BE(j).toString(16));
    }
    host = ipv6Parts.join(':');
    i += 16;
  } else {
    return false;
  }

  if (isBlockedDomain(host)) { ws.close(); return false; }
  ws.send(new Uint8Array([VERSION, 0]));
  
  const duplex = createWebSocketStream(ws);
  const onConnect = (targetHost) => {
    const conn = net.connect({ host: targetHost, port }, function () {
      if (i < msg.length) this.write(msg.slice(i));
      duplex.on('error', () => { }).pipe(this).on('error', () => { }).pipe(duplex);
    }).on('error', () => { duplex.destroy(); });
  };

  resolveHost(host)
    .then(resolvedIP => onConnect(resolvedIP))
    .catch(error => onConnect(host));

  return true;
}

// Tro-jan处理
function handleTrojConnection(ws, msg) {
  try {
    if (msg.length < 58) return false;
    const receivedPasswordHash = msg.slice(0, 56).toString();
    const hash = crypto.createHash('sha224').update(UUID).digest('hex');
    if (hash !== receivedPasswordHash) return false;

    let offset = 56;
    if (msg[offset] === 0x0d && msg[offset + 1] === 0x0a) offset += 2;
    else return false;

    if (msg.length < offset + 3) return false;
    const cmd = msg[offset];
    if (cmd !== 0x01) return false;
    offset += 1;
    const atyp = msg[offset];
    offset += 1;

    let host, port;
    if (atyp === 0x01) {
      if (msg.length < offset + 6) return false;
      host = msg.slice(offset, offset + 4).join('.'); offset += 4;
    } else if (atyp === 0x03) {
      if (msg.length < offset + 1) return false;
      const hostLen = msg[offset]; offset += 1;
      if (msg.length < offset + hostLen + 2) return false;
      host = msg.slice(offset, offset + hostLen).toString(); offset += hostLen;
    } else if (atyp === 0x04) {
      if (msg.length < offset + 18) return false;
      const ipv6Buf = msg.slice(offset, offset + 16);
      const ipv6Parts = [];
      for (let j = 0; j < 16; j += 2) {
        ipv6Parts.push(ipv6Buf.readUInt16BE(j).toString(16));
      }
      host = ipv6Parts.join(':'); offset += 16;
    } else { return false; }
    
    port = msg.readUInt16BE(offset); offset += 2;
    if (offset + 1 < msg.length && msg[offset] === 0x0d && msg[offset + 1] === 0x0a) offset += 2;

    if (isBlockedDomain(host)) { ws.close(); return false; }
    
    const duplex = createWebSocketStream(ws);
    const onConnect = (targetHost) => {
      const conn = net.connect({ host: targetHost, port }, function () {
        if (offset < msg.length) this.write(msg.slice(offset));
        duplex.on('error', () => { }).pipe(this).on('error', () => { }).pipe(duplex);
      }).on('error', () => { duplex.destroy(); });
    };

    resolveHost(host)
      .then(resolvedIP => onConnect(resolvedIP))
      .catch(error => onConnect(host));

    return true;
  } catch (error) { return false; }
}

// Ss处理
function handleSsConnection(ws, msg) {
  try {
    if (msg.length < 2) return false;
    let offset = 0;
    const atyp = msg[offset]; offset += 1;
    let host, port;
    
    if (atyp === 0x01) {
      if (msg.length < offset + 6) return false;
      host = msg.slice(offset, offset + 4).join('.'); offset += 4;
    } else if (atyp === 0x03) {
      if (msg.length < offset + 1) return false;
      const hostLen = msg[offset]; offset += 1;
      if (msg.length < offset + hostLen + 2) return false;
      host = msg.slice(offset, offset + hostLen).toString(); offset += hostLen;
    } else if (atyp === 0x04) {
      if (msg.length < offset + 18) return false;
      const ipv6Buf = msg.slice(offset, offset + 16);
      const ipv6Parts = [];
      for (let j = 0; j < 16; j += 2) {
        ipv6Parts.push(ipv6Buf.readUInt16BE(j).toString(16));
      }
      host = ipv6Parts.join(':'); offset += 16;
    } else { return false; }
    
    port = msg.readUInt16BE(offset); offset += 2;
    
    if (isBlockedDomain(host)) { ws.close(); return false; }
    
    const duplex = createWebSocketStream(ws);
    const onConnect = (targetHost) => {
      const conn = net.connect({ host: targetHost, port }, function () {
        if (offset < msg.length) this.write(msg.slice(offset));
        duplex.on('error', () => { }).pipe(this).on('error', () => { }).pipe(duplex);
      }).on('error', () => { duplex.destroy(); });
    };

    resolveHost(host)
      .then(resolvedIP => onConnect(resolvedIP))
      .catch(error => onConnect(host));

    return true;
  } catch (error) { return false; }
}

// Ws handler
const wss = new WebSocket.Server({ server: httpServer });
wss.on('connection', (ws, req) => {
  const url = req.url || '';
  const expectedPath = `/${WSPATH}`;
  if (!url.startsWith(expectedPath)) { ws.close(); return; }

  ws.once('message', msg => {
    // 修复：强制类型断言，拦截非二进制恶意文本帧
    if (!Buffer.isBuffer(msg)) { ws.close(); return; }

    if (msg.length > 17 && msg[0] === 0) {
      const id = msg.slice(1, 17);
      const isVless = id.every((v, i) => v == parseInt(uuid.substr(i * 2, 2), 16));
      if (isVless) { if (!handleVlsConnection(ws, msg)) ws.close(); return; }
    }
    if (msg.length >= 58) { if (handleTrojConnection(ws, msg)) return; }
    if (msg.length > 0 && (msg[0] === 0x01 || msg[0] === 0x03 || msg[0] === 0x04)) {
      if (handleSsConnection(ws, msg)) return;
    }
    ws.close();
  }).on('error', () => { });
});

// 添加自动保活任务
async function addAccessTask() {
  if (!AUTO_ACCESS) return;
  if (!DOMAIN) return;
  const fullURL = `https://${DOMAIN}/${SUB_PATH}`;
  try {
    await axios.post("https://oooo.serv00.net/add-url", { url: fullURL }, { headers: { 'Content-Type': 'application/json' } });
    console.log('Automatic Access Task added successfully');
  } catch (error) { }
}

// start service
httpServer.listen(PORT, () => {
  addAccessTask();
  console.log(`Server is running on ${PORT}`);
});
